// src/common/JokeGenerator.js

export async function getRandomJoke() {
  // Uses JokeAPI: https://v2.jokeapi.dev
  const endpoint = "https://v2.jokeapi.dev/joke/Any?safe-mode";
  try {
    const response = await fetch(endpoint);
    if (!response.ok) throw new Error("Failed to fetch joke.");
    const data = await response.json();

    if (data.type === "single") {
      return data.joke;
    } else if (data.type === "twopart") {
      return `${data.setup}\n${data.delivery}`;
    } else {
      return "Couldn't find a joke!";
    }
  } catch (error) {
    return "Sorry, couldn't get a joke - are you online?";
  }
}