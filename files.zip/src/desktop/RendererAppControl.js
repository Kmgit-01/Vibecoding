// Renderer process (UI code, e.g., React)
export async function openApp(appName) {
  if (window.voiceAssistantAPI) {
    const res = await window.voiceAssistantAPI.openApp(appName);
    if (!res.success) throw new Error(res.error);
    return res;
  } else {
    throw new Error("Not running in Electron desktop or voiceAssistantAPI unavailable.");
  }
}

export async function openFile(filePath) {
  if (window.voiceAssistantAPI) {
    const res = await window.voiceAssistantAPI.openFile(filePath);
    if (!res.success) throw new Error(res.error);
    return res;
  } else {
    throw new Error("Not running in Electron desktop or voiceAssistantAPI unavailable.");
  }
}

export async function systemAction(action) {
  if (window.voiceAssistantAPI) {
    const res = await window.voiceAssistantAPI.systemAction(action);
    if (!res.success) throw new Error(res.error);
    return res;
  } else {
    throw new Error("Not running in Electron desktop or voiceAssistantAPI unavailable.");
  }
}