const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const { openApplication, openFile, systemAction } = require("./src/desktop/ElectronAppControl");

function createWindow() {
  const win = new BrowserWindow({
    width: 1200, height: 800,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"), // Secure way to expose APIs
      contextIsolation: true, // Security best practices
      nodeIntegration: false, // Security best practices
    },
  });
  win.loadFile("public/index.html");
}

app.whenReady().then(createWindow);

// Example handlers for IPC commands from renderer
ipcMain.handle("open-app", async (event, appName) => {
  try {
    await openApplication(appName);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle("open-file", async (event, filePath) => {
  try {
    await openFile(filePath);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle("system-action", async (event, action) => {
  try {
    await systemAction(action);
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
});