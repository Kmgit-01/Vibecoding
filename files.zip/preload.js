// Preload script: exposes safe IPC APIs to renderer, prevents direct Node access.
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("voiceAssistantAPI", {
  openApp: async (appName) => await ipcRenderer.invoke("open-app", appName),
  openFile: async (filePath) => await ipcRenderer.invoke("open-file", filePath),
  systemAction: async (action) => await ipcRenderer.invoke("system-action", action),
  // Add more as needed!
});